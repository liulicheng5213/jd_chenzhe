[![Zhe's github stats](https://github-readme-stats.vercel.app/api?username=i-chenzhe)](https://github.com/anuraghazra/github-readme-stats)

### Zhe's Scripts 
- 我讨厌fork！ 我讨厌fork！ 我讨厌fork！
- 这里的脚本只是自己学习 js 的一个实践
- 仅用于测试和学习研究，禁止用于商业用途，不能保证其合法性，准确性，完整性和有效性，请根据情况自行判断.
- 仓库内所有资源文件，禁止任何公众号、自媒体进行任何形式的转载、发布。
- `i-chenzhe` 对任何脚本问题概不负责，包括但不限于由任何脚本错误导致的任何损失或损害.
- 间接使用脚本的任何用户，包括但不限于建立VPS或在某些行为违反国家/地区法律或相关法规的情况下进行传播, `i-chenzhe` 对于由此引起的任何隐私泄漏或其他后果概不负责.
- 如果任何单位或个人认为该项目的脚本可能涉嫌侵犯其权利，则应及时通知并提供身份证明，所有权证明，我们将在收到认证文件后删除相关脚本.
- 任何以任何方式查看此项目的人或直接或间接使用该Script项目的任何脚本的使用者都应仔细阅读此声明。 `i-chenzhe` 保留随时更改或补充此免责声明的权利。一旦使用并复制了任何相关脚本或Script项目的规则，则视为您已接受此免责声明.
- 您必须在下载后的24小时内从计算机或手机中完全删除以上内容.

### Zhe's TG
[  TG Chanel  ](https://t.me/something_bug)

[  TG Group  ](https://t.me/something_bug_group)
### 特别感谢
脚本使用了 [  @chavyleung  ](https://github.com/chavyleung) 大佬的 `Env` 函数

